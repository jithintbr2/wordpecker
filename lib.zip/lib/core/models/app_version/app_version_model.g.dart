// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_version_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AppVersionModel _$_$_AppVersionModelFromJson(Map<String, dynamic> json) {
  return _$_AppVersionModel(
    currentVersion: json['currentVersion'] as String?,
    minimumVersion: json['minimumVersion'] as String?,
  );
}

Map<String, dynamic> _$_$_AppVersionModelToJson(_$_AppVersionModel instance) =>
    <String, dynamic>{
      'currentVersion': instance.currentVersion,
      'minimumVersion': instance.minimumVersion,
    };
