part of 'request_item_history_bloc.dart';

@freezed
class RequestItemHistoryEvent with _$RequestItemHistoryEvent {
  const factory RequestItemHistoryEvent.getData() = _GetData;
}
