part of 'wallet_bloc.dart';

@freezed
class WalletEvent with _$WalletEvent {
  const factory WalletEvent.fetchWalletData() = _FetchWalletData;
  const factory WalletEvent.scratchCard(int cardId) = _ScratchCard;
}
