import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:path_provider/path_provider.dart';
import 'package:epub_viewer/epub_viewer.dart';

import '../../../core/models/home_page/home_page_model.dart';
import '../../../core/settings/config.dart';
import '../../widgets/category.dart';



class Epub extends HookWidget {
  bool loading = false;
  Dio dio = new Dio();
  String filePath = "";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('E-Pub'),
        ),
        body: Center(
          child: loading
              ? CircularProgressIndicator()
              : FlatButton(
            onPressed: () async {
              Directory? appDocDir = Platform.isAndroid
                  ? await getExternalStorageDirectory()
                  : await getApplicationDocumentsDirectory();

              String path = appDocDir!.path + '/a.epub';
              filePath=path;
              print(filePath);


              EpubViewer.setConfig(
                  themeColor: Theme.of(context).primaryColor,
                  identifier: "iosBook",
                  scrollDirection: EpubScrollDirection.ALLDIRECTIONS,
                  allowSharing: true,
                  enableTts: true,
                  nightMode: true);

              // get current locator
              EpubViewer.locatorStream.listen((locator) {
                print(
                    'LOCATOR: ${EpubLocator.fromJson(jsonDecode(locator))}');
              });

              EpubViewer.open(
                filePath,
                lastLocation: EpubLocator.fromJson({
                  "bookId": "2239",
                  "href": "/OEBPS/ch06.xhtml",
                  "created": 1539934158390,
                  "locations": {
                    "cfi": "epubcfi(/0!/4/4[simple_book]/2/2/6)"
                  }
                }),
              );

              // await EpubViewer.openAsset(
              //   'assets/4.epub',
              //   lastLocation: EpubLocator.fromJson({
              //     "bookId": "2239",
              //     "href": "/OEBPS/ch06.xhtml",
              //     "created": 1539934158390,
              //     "locations": {
              //       "cfi": "epubcfi(/0!/4/4[simple_book]/2/2/6)"
              //     }
              //   }),
              // );
            },
            child:_buildPage(context, data)

          ),
        ),
      ),
    );
  }
  _buildPage(BuildContext context, HomePageModel data) {
    return Stack(

      children: [
        ListView(
          shrinkWrap: true,

          padding: EdgeInsets.symmetric(vertical: 10),
          children: [

            Container(
                child: Category(
                  title: 'Items',
                  items: data.itemCategories ?? [],
                  limit: Config.itemCategoriesLimit,
                  onTap: (index) =>
                      Navigator.of(context).pushNamed('/itemList', arguments: {
                        "categories": data.itemCategories,
                        "categoryName": data.itemCategories![index].title,
                        "categoryId": data.itemCategories![index].id
                      }),
                ),
            ),





          ],
        ),
        // Align(
        //   alignment: Alignment.bottomCenter,
        //   child: data.isPendingOrders
        //       ? Container(
        //           color: Theme.of(context).primaryColor,
        //           child: ListTile(
        //               leading: Icon(
        //                 Icons.card_giftcard,
        //                 color: Colors.white,
        //               ),
        //               title: Text(
        //                 'Your orders are being processed.',
        //                 style: TextStyle(color: Colors.white),
        //               ),
        //               onTap: () => Navigator.pushNamed(context, '/orders')),
        //         )
        //       : SizedBox(),
        // )
      ],
    );
  }





}
